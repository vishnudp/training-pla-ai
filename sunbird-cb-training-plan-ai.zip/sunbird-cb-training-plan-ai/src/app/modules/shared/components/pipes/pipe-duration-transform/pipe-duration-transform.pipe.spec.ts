import { PipeDurationTransformPipe } from './pipe-duration-transform.pipe'

describe('PipeDurationTransformPipe', () => {
  it('create an instance', () => {
    const pipe = new PipeDurationTransformPipe()
    expect(pipe).toBeTruthy()
  })
})
