export const environment = {
  production: true,
  name: 'prod',
  contentHost: 'https://portal.igotkarmayogi.gov.in',
  contentBucket: 'assets/public'
};
